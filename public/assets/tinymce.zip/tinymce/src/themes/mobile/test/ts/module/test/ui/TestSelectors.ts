import { Fun } from '@ephox/katamari';

export default {
  link: Fun.constant('.tinymce-mobile-icon-link'),
  fontsize: Fun.constant('.tinymce-mobile-icon-font-size')
};